﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class ChangeKey : MonoBehaviour
{
    public GameObject model;
    // Start is called before the first frame update
    void Start()
    {
        this.GetComponent<Button>().onClick.AddListener(GoTry);
    }

    // Update is called once per frame
    void Update()
    {
        
    }
    void GoTry()
    {
        if (model.GetComponent<FoldingAndExpanding>().state == false)
            model.GetComponent<FoldingAndExpanding>().Folding();
        if (model.GetComponent<FoldingAndExpanding>().state == true)
            model.GetComponent<FoldingAndExpanding>().Expanding();
    }
}
