﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

public class Selector : MonoBehaviour
{
    private Camera _camera;
    private Animator cube_ani1, cube_ani2, cube_ani3;
    public RawImage point1,point2,point3;
    // Start is called before the first frame update
    void Start()
    {
        _camera=this.GetComponent<Camera>();
        cube_ani1 = GameObject.Find("Cube1").GetComponent<Animator>();
        cube_ani2 = GameObject.Find("Cube2").GetComponent<Animator>();
        cube_ani3 = GameObject.Find("Cube3").GetComponent<Animator>();
    }
    void OnGUI()
    {
        Ray ray = _camera.ScreenPointToRay(new Vector3(Screen.width/2, Screen.height/2, 0));    //定义一条射线，这条射线从摄像机屏幕射向鼠标所在位置
        RaycastHit hit;    //声明一个碰撞的点
        if (Physics.Raycast(ray, out hit))
        {    //如果真的发生了碰撞，ray这条射线在hit点与物体碰撞了
            if (hit.transform.tag == "Cube1")
            {//判断碰撞体是不是Cube
                cube_ani1.SetInteger("Animation_Int", 1);
                point1.enabled=true;
                if (Input.GetKeyDown(KeyCode.Return))
                {
                    SceneManager.LoadScene("PartOne Q1");
                }
            }
            else if(hit.transform.tag == "Cube2")
            {
                cube_ani2.SetInteger("Animation_Int", 1);
                point2.enabled = true;
                if (Input.GetKeyDown(KeyCode.Return))
                {
                    SceneManager.LoadScene("PartTwo Q1");
                }
            }
            else if(hit.transform.tag == "Cube3")
            {
                cube_ani3.SetInteger("Animation_Int", 1);
                point3.enabled = true;
                if (Input.GetKeyDown(KeyCode.Return))
                {
                    SceneManager.LoadScene("PartThree Q1");
                }
            }
            else
            {
                cube_ani1.SetInteger("Animation_Int", 0);
                cube_ani2.SetInteger("Animation_Int", 0);
                cube_ani3.SetInteger("Animation_Int", 0);
                point1.enabled = false;
                point2.enabled = false;
                point3.enabled = false;
            }
        }
    }
           // Update is called once per frame
    void Update()
    {
        
    }
}
