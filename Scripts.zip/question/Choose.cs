﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class Choose : Main
{
    public GameObject RightChoose;
    // Start is called before the first frame update
    void Start()
    {
        this.GetComponent<Button>().onClick.AddListener(AnswerChoosing);
    }

    // Update is called once per frame
    void Update()
    {
        
    }
    void AnswerChoosing()
    {
        if (this.gameObject.name == RightChoose.gameObject.name)
            Main.judge = true;
        else
            Main.judge = false;
        Debug.Log(judge);
    }
}
