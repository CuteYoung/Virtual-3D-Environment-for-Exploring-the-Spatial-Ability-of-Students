﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class ReChoose_2 : ReMain
{
    // Start is called before the first frame update
    void Start()
    {
        this.GetComponent<Button>().onClick.AddListener(AnswerChoosing);
    }

    // Update is called once per frame
    void Update()
    {

    }
    void AnswerChoosing()
    {
        if (this.gameObject.name == "optionA")
            ReMain.judge = false;
        if (this.gameObject.name == "optionB")
            ReMain.judge = true;
        if (this.gameObject.name == "optionC")
            ReMain.judge = false;
        if (this.gameObject.name == "optionD")
            ReMain.judge = false;
        if (this.gameObject.name == "optionE")
            ReMain.judge = false;
        if (this.gameObject.name == "optionF")
            ReMain.judge = false;
        Debug.Log(judge);
    }
}