﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Rotate : MonoBehaviour
{
    private Transform objTrans;
    // Start is called before the first frame update
    void Start()
    {
        objTrans = gameObject.GetComponent<Transform>();
    }

    // Update is called once per frame
    void Update()
    {
        MoveControl();
    }
    void  MoveControl()
    {
        if (Input.GetKey(KeyCode.W))
            objTrans.Rotate(Vector3.up ,1.0f);
        if (Input.GetKey(KeyCode.S))
            objTrans.Rotate(Vector3.down , 1.0f);
        if (Input.GetKey(KeyCode.A))
            objTrans.Rotate(Vector3.left, 1.0f);
        if (Input.GetKey(KeyCode.D))
            objTrans.Rotate(Vector3.right, 1.0f);
        if (Input.GetMouseButton(0))
        {
       objTrans.Rotate(Vector3.up, Input.GetAxis("Mouse X") * 10);
       objTrans.Rotate(Vector3.left, Input.GetAxis("Mouse Y") * 10);
        }
    }
}
