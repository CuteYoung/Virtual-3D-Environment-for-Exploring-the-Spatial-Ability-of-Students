﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class Choose_2 : Main
{
    // Start is called before the first frame update
    void Start()
    {
        this.GetComponent<Button>().onClick.AddListener(AnswerChoosing);
    }

    // Update is called once per frame
    void Update()
    {

    }
    void AnswerChoosing()
    {
        if (this.gameObject.name == "optionA")
            Main.judge = false;
        if (this.gameObject.name == "optionB")
            Main.judge = true;
        if (this.gameObject.name == "optionC")
            Main.judge = false;
        if (this.gameObject.name == "optionD")
            Main.judge = false;
        if (this.gameObject.name == "optionE")
            Main.judge = false;
        if (this.gameObject.name == "optionF")
            Main.judge = false;
        Debug.Log(judge);
    }
}