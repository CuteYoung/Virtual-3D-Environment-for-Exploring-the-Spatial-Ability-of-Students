﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class NextStep: MonoBehaviour
{
    public GameObject exploring;
    public GameObject hands;
    // Start is called before the first frame update
    void Start()
    {
        this.GetComponent<Button>().onClick.AddListener(nextPart);
    }

    // Update is called once per frame
    void Update()
    {
        
    }
    void nextPart()
    {
        hands.gameObject.SetActive(true);
        transform.parent.gameObject.SetActive(false);
        exploring.SetActive(true);
    }
}
