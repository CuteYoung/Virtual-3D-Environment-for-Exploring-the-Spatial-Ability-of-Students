﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class ReChoose : ReMain
{
    public GameObject RightChoose;
    // Start is called before the first frame update
    void Start()
    {
        this.GetComponent<Button>().onClick.AddListener(AnswerChoosing);
    }

    // Update is called once per frame
    void Update()
    {
        
    }
    void AnswerChoosing()
    {
        if (this.gameObject.name == RightChoose.gameObject.name)
            ReMain.judge = true;
        else
            ReMain.judge = false;
        Debug.Log(judge);
    }
}
