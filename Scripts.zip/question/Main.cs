﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class Main : MonoBehaviour
{
    public static bool judge = false;     //设置布尔变量judge判断题目是否正确
    public  GameObject  goToCanvas;
    // Start is called before the first frame update
    void Start()
    {
        this.GetComponent<Button>().onClick.AddListener(PutComments);
        
    }

    // Update is called once per frame
    void Update()
    {
        
    }
    void PutComments()
    {
        goToCanvas.SetActive(true);
        transform.parent.gameObject.SetActive(false);
    }
}
