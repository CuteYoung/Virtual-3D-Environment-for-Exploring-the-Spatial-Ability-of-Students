﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CombinationAct : MonoBehaviour
{
    private GameObject aim;
    //private Vector3 aimPosition;
    //private Vector3 aimRotation;
    // Start is called before the first frame update
    void Start()
    {
    }

    // Update is called once per frame
    void Update()
    {
       Division();
    }
    private void OnTriggerEnter(Collider other)
    {
        aim = other.gameObject;
        other.transform.parent = this.transform;
        Debug.Log("进入");
    }
    void Division()
    {
        if (Input.GetKeyDown(KeyCode.Escape))
        {
            aim.transform.parent = this.transform.parent.transform;
            aim.transform.eulerAngles = new Vector3(0, 0, 0);
            Debug.Log("division");
        }
    }
    //private void OnTriggerStay(Collider other)
    //{
    //    Debug.Log("stay");
    //}
    //private void OnTriggerExit(Collider other)
    //{
    //    if (other.gameObject == aim)
    //    {
    //        other.transform.parent = this.transform.parent.transform;
    //        other.transform.eulerAngles = new Vector3(0, 0, 0);
    //        Debug.Log("离开");
    //    }
    //}
    //private void OnCollisionEnter(Collision collision)
    //{
    //    collision.collider.gameObject.transform.parent = this.transform;
    //    Debug.Log("进入");
    //}
    //private void OnCollisionExit(Collision collision)
    //{
    //    Debug.Log("离开");
    //    collision.collider.gameObject.transform.parent = this.transform.parent.transform;
    //    //collision.collider.gameObject.transform.eulerAngles = new Vector3(0, 0, 0);
    //}

}

