﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class FoldingAndExpanding : MonoBehaviour
{
    public GameObject joint1;
    public GameObject joint2;
    public GameObject joint3;
    public GameObject joint4;
    public GameObject joint5;
    public bool state;
    // Start is called before the first frame update
    void Start()
    {
        state = false;
    }
    // Update is called once per frame
    void Update()
    {
    }
    public void Folding()
    {
        this.transform.eulerAngles = new Vector3(0, 0, 0);
        iTween.RotateTo (joint1,iTween.Hash("rotation", new Vector3(90, 0, 0), "easeType",iTween.EaseType.linear,"time", 4f));
        iTween.RotateTo(joint2, iTween.Hash("rotation", new Vector3(-90, 0, 0), "easeType", iTween.EaseType.linear, "time", 4f));
        iTween.RotateTo(joint3, iTween.Hash("rotation", new Vector3(0, 0, 90), "easeType", iTween.EaseType.linear, "time", 4f));
        iTween.RotateTo(joint4, iTween.Hash("rotation", new Vector3(0, 0, -90), "easeType", iTween.EaseType.linear, "time", 4f));
        iTween.RotateTo(joint5, iTween.Hash("rotation", new Vector3(0, 0, -180), "easeType", iTween.EaseType.linear, "time", 4f));
        Invoke("StateChange",4);
    }
    public void Expanding()
    {
        this.transform.eulerAngles = new Vector3(0, 0, 0);
        iTween.RotateTo(joint1, iTween.Hash("rotation", new Vector3(0, 0, 0), "easeType", iTween.EaseType.linear, "time", 4f));
        iTween.RotateTo(joint2, iTween.Hash("rotation", new Vector3(0, 0, 0), "easeType", iTween.EaseType.linear, "time", 4f));
        iTween.RotateTo(joint3, iTween.Hash("rotation", new Vector3(0, 0, 0), "easeType", iTween.EaseType.linear, "time", 4f));
        iTween.RotateTo(joint4, iTween.Hash("rotation", new Vector3(0, 0, 0), "easeType", iTween.EaseType.linear, "time", 4f));
        iTween.RotateTo(joint5, iTween.Hash("rotation", new Vector3(0, 0, -0.001f), "easeType", iTween.EaseType.linear, "time", 4f));
        Invoke("StateChange", 4);
    }
    void StateChange()
    {
        state = !state;
    }
}
