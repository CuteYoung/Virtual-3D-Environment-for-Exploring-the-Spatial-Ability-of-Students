﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class Clock1 : StartAnswer
{
    // Start is called before the first frame update
    private int usingTime;
    private Text TimerText;
    void OnEnable()
    {
        usingTime = 0;
        TimerText = this.GetComponent<Text>();
        StartCoroutine("OpenTimer", usingTime);
    }
    IEnumerator OpenTimer(int timer)
    {
        TimerText.text = string.Format("{0:D2}:{1:D2}", timer / 60, timer % 60);
        while (timer < 999)
        {
            yield return new WaitForSeconds(1);
            timer++;
            TimerText.text = string.Format("{0:D2}:{1:D2}", timer / 60, timer % 60);
            PlayerPrefs.SetInt("Time1", timer);
        }
    }
    // Update is called once per frame
    void Update()
    {
        
    }
}
