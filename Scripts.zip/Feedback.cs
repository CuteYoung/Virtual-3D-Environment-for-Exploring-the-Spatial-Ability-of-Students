﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using System;

public class Feedback :StartAnswer
{
    public GameObject ReDo;
    private bool answer1;
    private bool answer2;
    private int usingTime;
    // Start is called before the first frame update
    void OnEnable()
    {
        FeedBack();
    }

    // Update is called once per frame
    void Update()
    {
        
    }
    void FeedBack()
    {
        Debug.Log(TryTimeCounter.tryTimes);
        Debug.Log(Main.judge);
        Debug.Log(ReMain.judge);
        answer1 = Main.judge;
        answer2 = ReMain.judge;
        usingTime = PlayerPrefs.GetInt("Time1")+ PlayerPrefs.GetInt("Time2");   //计算总的用时，单位秒
        if (answer2)
        {
            ReDo.gameObject.SetActive(false);
            if (TryTimeCounter.tryTimes == 1)
            {
                if (answer1)
                    this.GetComponent<Text>().text = string.Format("恭喜你答对这道题，用时{0:D2}秒，你的空间想象能力很棒！", usingTime);
                if (!answer1)
                    this.GetComponent<Text>().text = string.Format("恭喜你，经过探究后强化了你的空间想象能力并答对这道题，用时{0:D2}秒！", usingTime);
            }
            if(TryTimeCounter.tryTimes>1)
                this.GetComponent<Text>().text = string.Format("恭喜你再次探究后答对这道题，用时{0:D2}秒", PlayerPrefs.GetInt("Time2"));

        }
        if (!answer2)
        {

            ReDo.gameObject.SetActive(true);
            if (TryTimeCounter.tryTimes == 1)
            {
                if (answer1 && usingTime >= 30)
                    this.GetComponent<Text>().text = string.Format("假设答案正确，很遗憾在探究后选择了错误答案，用时{0:D2}秒，建议重新进行该题的探究！", usingTime);
                if (answer1 && usingTime < 30)
                    this.GetComponent<Text>().text = string.Format("假设答案正确，很遗憾在探究后选择了错误答案，用时{0:D2}秒，建议适当延长时间重新进行该题的探究！", usingTime);
                if (!answer1 && usingTime >= 30)
                    this.GetComponent<Text>().text = string.Format("很遗憾探究后依旧选择了错误答案，用时{0:D2}秒，建议重新进行该题的探究！", usingTime);
                if (!answer1 && usingTime < 30)
                    this.GetComponent<Text>().text = string.Format("很遗憾探究后依旧选择了错误答案，用时{0:D2}秒，建议适当延长时间重新进行该题的探究！", usingTime);
            }
            if(TryTimeCounter.tryTimes>1)
                this.GetComponent<Text>().text = string.Format("很遗憾再次探究后依旧选择了错误答案，用时{0:D2}秒，建议适当延长时间重新进行该题的探究，也可更换题目练习！", PlayerPrefs.GetInt("Time2"));

        }
    }
}
