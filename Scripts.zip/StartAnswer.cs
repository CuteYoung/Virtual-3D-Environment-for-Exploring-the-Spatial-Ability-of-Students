﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using System;

public class StartAnswer : MonoBehaviour
{
    public static int startTimeM;
    public static int startTimeS;
    public GameObject questionCanvas;
    // Start is called before the first frame update
    void Start()
    {
        this.GetComponent<Button>().onClick.AddListener(Begin);
    }

    // Update is called once per frame
    void Update()
    {
        
    }
    private void Begin()
    {
        startTimeM = DateTime.Now.Minute;
        startTimeS = DateTime.Now.Second;
        transform.parent.gameObject.SetActive(false);
        questionCanvas.SetActive(true);
    }
}
