﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ChoosePart : MonoBehaviour
{
    private GameObject[] m_Select;
    // Start is called before the first frame update
    void Start()
    {
        m_Select = GameObject.FindGameObjectsWithTag("SelectObject");
    }

    // Update is called once per frame
    void Update()
    {
        GetPart();
    }
    void GetPart()
    {
        if (Input.GetMouseButtonDown(0))
        {  
            for (int i = 0; i < m_Select.Length; i++)  //遍历数组
            {
                m_Select[i].GetComponent<MoveAndRotate>().enabled = false;
            }
            Ray ray = Camera.main.ScreenPointToRay(Input.mousePosition);
            RaycastHit hit;
            if (Physics.Raycast(ray, out hit))
            {
                GameObject go = hit.collider.gameObject;    //获得选中物体
                go.GetComponent<MoveAndRotate>().enabled =!(go.GetComponent<MoveAndRotate>().enabled);
            }
        }
    }
}


