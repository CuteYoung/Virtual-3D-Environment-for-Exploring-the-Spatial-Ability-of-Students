﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Mouse_Rotation : MonoBehaviour
{
    private float OffsetX = 0;
    private float OffsetY = 0;
    public float speed = 6f;//旋转速度
    void Update()
    {
        if (Input.GetMouseButton(0))
        {
            OffsetX = Input.GetAxis("Mouse X");//获取鼠标x轴的偏移量
            OffsetY = Input.GetAxis("Mouse Y");//获取鼠标y轴的偏移量

            transform.Rotate(new Vector3(OffsetY, -OffsetX, 0) * speed, Space.World);
        }
    }
}
