﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class GoBack : MonoBehaviour
{
    public GameObject goAgain;
    public GameObject Hands;
    // Start is called before the first frame update
    void Start()
    {
        this.gameObject.GetComponent<Button>().onClick.AddListener(goBack);
    }

    // Update is called once per frame
    void Update()
    {
        
    }
    void goBack()
    {
        TryTimeCounter.tryTimes++;
        goAgain.gameObject.SetActive(true);        
        this.transform.parent.gameObject.SetActive(false);
        Hands.SetActive(true);
    }
}
